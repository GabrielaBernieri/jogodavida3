
var celulaviva = false;
var vizinhasvivas = 0;
var vivanaproxima = false;
var animação = false;

var fps = 20;
var intervalo = 1000 / fps;
var size = 600;
var lado = 20;
var borda = 1;

celulas = [];

function init() {
let canvas = document.getElementById('tela');
canvas.width = 600;
canvas.height = 600;
let numberOfCells = size / lado;
for (let i = 0; i < numberOfCells; i += 1) {
	let line = [];
	celulas.push(line);
	for (let j = 0; j < numberOfCells; j += 1) {
	line.push(false);
	drawCell({'x': j, 'y': i}, canvas);
}
}

console.log(celulas);

canvas.addEventListener('mousedown', function(e) {
	let pos = getCursorPosition(canvas, e);
	handleClick(pos, canvas);
});
}


function handleClick(pos, canvas) {
	celulas[pos.y][pos.x] = !celulas[pos.y][pos.x];
	drawCell(pos, canvas)
}

function drawCell(pos, canvas) {
	let x = pos.x * lado;
	let y = pos.y * lado;
	let ctx = canvas.getContext('2d');
	if (celulas[pos.y][pos.x]) {
	ctx.fillStyle = 'deepskyblue';
	ctx.fillRect(x + borda, y + borda, lado - (borda * 2), lado - (borda * 2));
	} else {
		ctx.lineWidth = borda;
		ctx.strokeStyle = 'black';
		ctx.fillStyle = 'white';
		ctx.fillRect(x + borda, y + borda, lado - (borda * 2), lado - (borda * 2));
		ctx.rect(x + borda, y + borda, lado - (borda * 2), lado - (borda * 2));
	}
}

function getCursorPosition(canvas, event) {
	const rect = canvas.getBoundingClientRect();
	const x = event.clientX - rect.left;
	const y = event.clientY - rect.top;
	return {"x": Math.floor(x/lado), "y": Math.floor(y/lado)}
}

function jogo(pos,canva){
	if vizinhasvivas < 2:
		vivanaproxima = false;
		celulaviva = false;
	if vizinhasvivas > 3:
		vivanaproxima = false;
		celulaviva = false;
	if vizinhasvivas == 3:
		vivanaproxima = true;
		celulaviva = true;
	if vivanaproxima == 2:
		vivanaproxima = true;
		celulaviva = true;
}
